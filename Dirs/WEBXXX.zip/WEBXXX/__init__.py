import os, requests

API_FROM = "https://lust.scathach.id"
webs = ["redtube", "youporn"]
funcs = ["search", "get"]

def func(name):
    output = ""
    if name == "search":
        os.system("clear")
        flag = str(input(" search : "))
        output += "search?key=" + flag
    elif name == "get":
        os.system("clear")
        flag = str(input(" get ID : "))
        output += "get?id=" + flag
    elif name == "" or name == False:
        os.system("clear")
        flag = str(input(" search : "))
        output += "search?key=" + flag
    return output

def web(name):
    flag = name
    if flag == "" or flag == False: flag += webs[0]
    return flag

def site(webname, funcname):
    output = "/" + web(webname)
    output += "/" + func(funcname)
    return API_FROM + output

def detell():
    os.system("clear")
    output = []
    url_apis = ""
    run_loop = True
    while run_loop:
        print("\n Web Sites : " + str(webs) + "\n")
        web_name = str(input(" Wensite ? : "))

        print("\n funcs : " + str(funcs) + "\n")
        func_name = str(input(" func ? : "))

        url_api = str(site(web_name, func_name))
        url_apis += " " + url_api + "\n"
        print(url_apis)

        response = requests.get(url_api)
        json_data = response.json()
        if json_data["success"] == True and json_data["data"] != False:
            print(response)
            for i in json_data["data"]:
                output.append(i)
            if str(input(" Enter to Live Server ? ")) == "":
                run_loop = False
                break
        else:
            print(response)
            print("data error")
    
    return output