import __init__
from http.server import HTTPServer, BaseHTTPRequestHandler

class helloHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path == '/.cache/mainprogram.html'
        try:
            file_to_open = open('.cache/mainprogram.html').read()
            self.send_response(200)
        except:
            file_to_open = "file not found"
            self.send_response(404)
        self.send_header('content-type', 'text/html')
        self.end_headers()
        self.wfile.write(bytes(file_to_open, 'utf-8'))


def html_index(textHTML = str):
    html = '<!DOCTYPE html>\n'+'<html lang="en">\n'+'<head>\n'
    html += '    <meta charset="UTF-8">\n'
    html += '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
    html += '    <title>Live Server</title>\n'
    html += '    <style>*{padding: 0;margin: 0; box-sizing: border-box;}</style>\n'
    html += '</head>\n'+'<body>\n'
    html += textHTML
    html += '\n</body>'+'\n'+'</html>'+'\n'
    return html

def html_iframe(src = str):
    return '\n    <section><iframe src="' + str(src) + '" frameborder="1" style="padding: 0;margin: 0;" width="720" height="640"></iframe></section>\n'

def webStart():
    init_class = __init__
    video_iframe = ""
    file = open(".cache/mainprogram.html", "w")
    detell_data = init_class.detell()
    for i in detell_data:
        print(i)
        video_iframe += html_iframe(i['video'])
    html = html_index(video_iframe)
    video_iframe = False
    detell_data = False
    file.write(html)

def main():
    PORT = 8000
    server = HTTPServer(('', PORT),helloHandler)
    print('Server running on port %s' % PORT)
    server.serve_forever()

if __name__ == "__main__":
    webStart()
    main()