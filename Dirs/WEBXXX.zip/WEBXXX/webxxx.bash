#!/bin/bash

[ -f $PWD/.venv/bin/activate ] && . .venv/bin/activate
python __main__.py