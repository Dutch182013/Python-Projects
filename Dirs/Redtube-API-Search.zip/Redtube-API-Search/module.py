
def search(string_data = ""):
    data = ""
    for i in string_data:
        if i == ' ':
            i = '%20'
        elif i == '\n':
            i = '%0A'
        elif i == '+':
            i = '%2B'
        data += str(i)
    output = 'https://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search=' + data + "=Teen&thumbsize=all"
    print(output)
    return output