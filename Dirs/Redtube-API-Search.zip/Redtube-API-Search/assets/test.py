import requests

num = 0
for i in requests.get('https://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search=CarleCute').json()['videos']:
    print(i['video']['title'], '\n')
    num += 1
    print(num)