import requests
import module

from http.server import HTTPServer, BaseHTTPRequestHandler
class helloHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == 'src/index.html':
            self.path == 'src/index.html'
        try:
            file_to_open = open('src/index.html').read()
            self.send_response(200)
        except:
            file_to_open = "file not found"
            self.send_response(404)
        self.send_header('content-type', 'text/html')
        self.end_headers()
        self.wfile.write(bytes(file_to_open, 'utf-8'))


def html_index(textHTML = str):
    html = '<!DOCTYPE html>\n'+'<html lang="en">\n'+'<head>\n'
    html += '    <meta charset="UTF-8">\n'
    html += '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
    html += '    <title>Live Server</title>\n'
    html += '    <style>*{padding: 0;margin: 0; box-sizing: border-box;}</style>\n'
    html += '</head>\n'+'<body>\n'
    html += textHTML
    html += '\n</body>'+'\n'+'</html>'+'\n'
    return html

def html_iframe(src = str):
    return '\n    <section><iframe src="' + str(src) + '" frameborder="1" style="padding: 0;margin: 0;" width="720" height="640"></iframe></section>\n'

def create(setPath = "src/index.html", data = ""):
    open(str(setPath), 'w').write(str(data))
    print("compiled")

def search(str_data):
    output = ""
    response = requests.get(module.search(str(str_data)))
    json_data = response.json() # json_data = [{videos:?}, {count:?}]
    data_videos = json_data['videos']
    data_count = json_data['count']
    print(" count " + str(data_count) + "\n")
    frame_videos = ""
    for i in data_videos:
        title = i['video']['title']
        video_embed = i['video']['embed_url']
        print(str(title))
        frame_videos += html_iframe(str(video_embed))
    output += html_index(frame_videos)
    create("src/index.html", output)

# print(data_videos)
# print(data_count)

def mainserver():
    PORT = 8000
    server = HTTPServer(('', PORT),helloHandler)
    print('Server running on port http://127.0.0.1:%s' % PORT)
    server.serve_forever()

if __name__ == "__main__":
    while True:
        print("Redtube Server")
        user_input = str(input( "Title : " ))
        if user_input == "":
            pass
        elif user_input == "exit":
            print(' Close Programe an Exit. ')
            exit()
        elif user_input != "":
            search(user_input)
            break
    mainserver()